
[`Action`]: https://bazel.build/rules/lib/Action
[`bool`]: https://bazel.build/rules/lib/bool
[`depset`]: https://bazel.build/rules/lib/depset
[`dict`]: https://bazel.build/rules/lib/dict
[`File`]: https://bazel.build/rules/lib/File
[`Label`]: https://bazel.build/rules/lib/Label
[`list`]: https://bazel.build/rules/lib/list
[`str`]: https://bazel.build/rules/lib/string
[str]: https://bazel.build/rules/lib/string
[`int`]: https://bazel.build/rules/lib/int
[`struct`]: https://bazel.build/rules/lib/builtins/struct
[`Target`]: https://bazel.build/rules/lib/Target
[target-name]: https://bazel.build/concepts/labels#target-names
[attr-label]: https://bazel.build/concepts/labels
