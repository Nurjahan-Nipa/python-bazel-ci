# compile_pip_requirements

This test ensures that generated requirements.in can be used by compile_pip_requirements.
