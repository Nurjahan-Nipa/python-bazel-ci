# Toolchains testing WORKSPACE template

This directory contains templates for generating acceptance tests for the
toolchains.
