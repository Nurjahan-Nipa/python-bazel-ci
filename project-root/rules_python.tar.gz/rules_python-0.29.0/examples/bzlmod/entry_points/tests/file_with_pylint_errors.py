"""
A file to demonstrate the pylint-print checker works.
"""

if __name__ == "__main__":
    print("Hello, World!")
