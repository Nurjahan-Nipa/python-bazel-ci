import lib2

if __name__ == "__main__":
    lib2.lib_and_main.library_func()
