# Same package imports
This test case asserts that no `deps` is needed when a module imports another module in the same package