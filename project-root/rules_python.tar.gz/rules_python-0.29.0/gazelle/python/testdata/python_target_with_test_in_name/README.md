# Python target with test in name

Cover the case where a python file either starts with `test_` or ends with `_test`, but is not an actual test.
