# With std requirements

This test case asserts that a `py_library` is generated without any `deps` since
it only imports Python standard library packages.
