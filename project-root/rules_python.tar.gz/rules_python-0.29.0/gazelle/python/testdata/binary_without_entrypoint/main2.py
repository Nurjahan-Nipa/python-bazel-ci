import collided_main

if __name__ == "__main__":
    run()
