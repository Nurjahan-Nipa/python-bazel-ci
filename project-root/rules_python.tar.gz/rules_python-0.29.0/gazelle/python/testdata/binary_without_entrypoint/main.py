import collided_main
import pandas

if __name__ == "__main__":
    run()