# Simple library without `__init__.py`

This test case asserts that a simple `py_library` is generated as expected
without an `__init__.py` but with a `BUILD` file marking it as a package.
