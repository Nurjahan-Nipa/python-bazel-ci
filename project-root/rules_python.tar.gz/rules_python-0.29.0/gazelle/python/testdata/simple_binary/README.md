# Simple binary

This test case asserts that a simple `py_binary` is generated as expected.
