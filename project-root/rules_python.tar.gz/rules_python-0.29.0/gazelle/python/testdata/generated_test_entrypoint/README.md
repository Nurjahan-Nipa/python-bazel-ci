# Generated test entrypoint

This test case asserts that a `py_test` is generated using a target named
`__test__` as its `main` entrypoint.
